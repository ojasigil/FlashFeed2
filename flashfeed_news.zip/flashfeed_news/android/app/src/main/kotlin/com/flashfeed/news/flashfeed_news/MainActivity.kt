package com.flashfeed.news.flashfeed_news

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
